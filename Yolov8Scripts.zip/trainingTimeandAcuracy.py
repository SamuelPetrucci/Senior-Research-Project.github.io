import pandas as pd

# Path to your CSV file (update the path to your actual file location)
file_path = r'runs\detect\train10\results.csv'

# Import the CSV file into a pandas DataFrame
df = pd.read_csv(file_path)

# Calculate the time spent in each epoch (difference between consecutive epochs)
df['epoch_time'] = df['time'].diff()

# The first epoch will have a NaN value, so we can ignore it by dropping it
df = df.dropna(subset=['epoch_time'])

# Calculate the average epoch time
avg_time_per_epoch = df['epoch_time'].mean()

# Get the maximum mAP50 accuracy from the 'metrics/mAP50(B)' column
max_mAP50_per_epoch = df['metrics/mAP50(B)'].max()

# Create a summary table with the calculated average training time and maximum mAP50 accuracy
summary_table = pd.DataFrame({
    'Average Training Time (sec) per Epoch': [avg_time_per_epoch],
    'Max mAP50 Accuracy': [max_mAP50_per_epoch]
})

# Display the summary table
print(summary_table)
