import asyncio
from ultralytics import YOLO

async def train_model():
    model = YOLO("yolov8n.yaml")  # build a new model from scratch
    results = await asyncio.to_thread(model.train, data="data.yaml", epochs=250, batch=16, imgsz=640, amp=True)
    return results

async def main():
    results = await train_model()
    print("Training completed:", results)

asyncio.run(main())