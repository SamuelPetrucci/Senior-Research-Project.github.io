import os
import cv2
from ultralytics import YOLO

# Directory setup
IMAGES_DIR = os.path.join('C:\\', 'Users', 'petruccis', 'Desktop', 'Yolov8_gun_detection', "GunImages")
output_dir = os.path.join(IMAGES_DIR, 'output')
os.makedirs(output_dir, exist_ok=True)

# YOLOv8 model setup
model_path = os.path.join('.', 'runs', 'detect', 'train10', 'weights', 'last.pt')
model = YOLO(model_path)

# Detection threshold
threshold = 0.5

# Process each image in the folder
for image_name in os.listdir(IMAGES_DIR):
    if image_name.lower().endswith(('.jpg', '.jpeg', '.png')):
        image_path = os.path.join(IMAGES_DIR, image_name)
        image_path_out = os.path.join(output_dir, f"{os.path.splitext(image_name)[0]}_out.jpg")

        # Load image
        frame = cv2.imread(image_path)
        if frame is None:
            print(f"Error: Could not open image {image_path}. Skipping.")
            continue

        # Run detection
        results = model(frame)[0]

        # Draw bounding boxes
        for result in results.boxes.data.tolist():
            x1, y1, x2, y2, score, class_id = result
            if score > threshold:
                cv2.rectangle(frame, (int(x1), int(y1)), (int(x2), int(y2)), (0, 255, 0), 4)
                cv2.putText(frame, results.names[int(class_id)].upper(), (int(x1), int(y1) - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 1.3, (0, 255, 0), 3, cv2.LINE_AA)

        # Save the output image
        cv2.imwrite(image_path_out, frame)
        print(f"Processed and saved: {image_path_out}")

print("Processing complete.")
