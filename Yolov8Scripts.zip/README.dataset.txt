# gun > 2024-06-20 8:21am
https://universe.roboflow.com/detection-8xl9g/gun-bg9a9

Provided by a Roboflow user
License: CC BY 4.0

