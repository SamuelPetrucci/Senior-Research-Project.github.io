import pandas as pd
import matplotlib.pyplot as plt

# Load the data from a CSV file
# Replace 'your_data.csv' with the path to your file
data = pd.read_csv(r'runs\detect\train10 500 epochs 650 imgs\results.csv')

# Extract the columns for epoch, training loss, and validation loss
epochs = data['epoch']
train_loss = data['train/cls_loss']
val_loss = data['val/cls_loss']

# Create the plot
plt.figure(figsize=(10, 6))
plt.plot(epochs, train_loss, label='Training Loss', marker='o')
plt.plot(epochs, val_loss, label='Validation Loss', marker='o', linestyle='--')

# Add titles and labels
plt.title('YOLOv8 Training and Validation Loss over Epochs')
plt.xlabel('Epoch')
plt.ylabel('Loss')
plt.legend()

# Show grid and plot
plt.grid(True)
plt.show()
